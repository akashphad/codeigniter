#
# TABLE STRUCTURE FOR: customers
#

DROP TABLE IF EXISTS `customers`;

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '1=Active | 0=Inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `created`, `modified`, `status`) VALUES (1, 'test', 'test@gmail.com', '1010101010', 'test address', '2021-02-21 09:09:52', '2021-02-21 09:09:52', '1');
INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `created`, `modified`, `status`) VALUES (2, 'Akash Phad', 'phad.akash2000@gmail.com', '09545627203', 'MIT School of Engineering, MIT ADT University, Pune, Maharashtra, India.', '2021-03-18 21:16:34', '2021-03-18 21:16:34', '1');
INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `created`, `modified`, `status`) VALUES (3, 'asdasda wda', 'test1@tes.com', '5627203', 'Maharashtra, India.', '2021-03-18 21:28:59', '2021-03-18 21:28:59', '1');
INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `created`, `modified`, `status`) VALUES (4, 'asdasd sdsad', 'test2@test.com', '787878787', 'asdsadsa cassd', '2021-03-18 21:29:51', '2021-03-18 21:29:51', '1');
INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `created`, `modified`, `status`) VALUES (5, 'testr', 'test3@test.com', '454545454', 'eqwewq dfsdf', '2021-03-18 21:32:15', '2021-03-18 21:32:15', '1');
INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `created`, `modified`, `status`) VALUES (6, 'Akshay Lukaday', 'akshaylukaday@gmail.com', '9999555525', 'xyv, xyv ,Pune, Maharashtra 412307', '2021-03-31 07:45:24', '2021-03-31 07:45:24', '1');


#
# TABLE STRUCTURE FOR: order_items
#

DROP TABLE IF EXISTS `order_items`;

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(5) NOT NULL,
  `sub_total` float(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `sub_total`) VALUES (1, 1, 3, 2, '111110.00');
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `sub_total`) VALUES (2, 2, 17, 1, '19800.00');
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `sub_total`) VALUES (3, 3, 17, 1, '19800.00');
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `sub_total`) VALUES (4, 3, 2, 1, '42999.00');
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `sub_total`) VALUES (5, 4, 1, 1, '18990.00');
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `sub_total`) VALUES (6, 5, 5, 1, '27999.00');
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `sub_total`) VALUES (7, 6, 4, 1, '49990.00');
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `sub_total`) VALUES (8, 6, 17, 1, '19800.00');


#
# TABLE STRUCTURE FOR: orders
#

DROP TABLE IF EXISTS `orders`;

CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `grand_total` float(10,2) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '1=Active | 0=Inactive',
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `orders` (`id`, `customer_id`, `grand_total`, `created`, `modified`, `status`) VALUES (1, 1, '111110.00', '2021-02-21 09:09:52', '2021-02-21 09:09:52', '1');
INSERT INTO `orders` (`id`, `customer_id`, `grand_total`, `created`, `modified`, `status`) VALUES (2, 2, '19800.00', '2021-03-18 21:16:34', '2021-03-18 21:16:34', '1');
INSERT INTO `orders` (`id`, `customer_id`, `grand_total`, `created`, `modified`, `status`) VALUES (3, 3, '62799.00', '2021-03-18 21:29:00', '2021-03-18 21:29:00', '1');
INSERT INTO `orders` (`id`, `customer_id`, `grand_total`, `created`, `modified`, `status`) VALUES (4, 4, '18990.00', '2021-03-18 21:29:51', '2021-03-18 21:29:51', '1');
INSERT INTO `orders` (`id`, `customer_id`, `grand_total`, `created`, `modified`, `status`) VALUES (5, 5, '27999.00', '2021-03-18 21:32:15', '2021-03-18 21:32:15', '1');
INSERT INTO `orders` (`id`, `customer_id`, `grand_total`, `created`, `modified`, `status`) VALUES (6, 6, '69790.00', '2021-03-31 07:45:24', '2021-03-31 07:45:24', '1');


#
# TABLE STRUCTURE FOR: products
#

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `price` float(10,2) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '1=Active | 0=Inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `products` (`id`, `image`, `name`, `description`, `price`, `created`, `modified`, `status`) VALUES (1, '3.jpg', 'Redmi Note 9 Pro', 'The Redmi Note 9 Pro is powerful and everyday work will go smoothly. The display is large and crisp, making games and movies look good.The 16.9cm(6.67\") large display with rounded corner design and dot notch display. Qualcomm Snapdragon 720G octa-core processor with 8nm technology; coupled with MIUI 11 system level optimisations enables low power consumption for a longer battery life. 48MP Quad camera with high resolution camera.', '18990.00', '2021-02-01 10:34:06', '2021-02-21 10:34:06', '1');
INSERT INTO `products` (`id`, `image`, `name`, `description`, `price`, `created`, `modified`, `status`) VALUES (2, '2.jpg', 'Oneplus 8T', 'OnePlus 8T is a high-end smartphone from the brand, with 128GB storage space, best in class 8GB RAM, accompanied by an excellent display setup. OnePlus 8T features a 6.55-inch FHD+ Fluid AMOLED display, having a screen resolution of 1080 x 2400 pixels. The all new OnePlus 8T 5G - ultra stops at nothing - loaded with snapdragon 865 processor, 5G connectivity, 120hz fluid amoled display, 65W warp charging, rear quad camera setup', '42999.00', '2021-02-01 10:34:06', '2021-02-21 10:34:06', '1');
INSERT INTO `products` (`id`, `image`, `name`, `description`, `price`, `created`, `modified`, `status`) VALUES (3, '9.jpg', 'Samsung Galaxy S21', 'Meet Galaxy S21 5G Designed to revolutionize video and photography, with beyond cinematic 8K resolution so you can snap epic photos right out of video. It has it all in two sizes: 64MP, our fastest chip and a massive all-day battery. Quad rear camera setup- Main Camera 108MP + Ultra Wide 12MP Dual Pixel Camera + Tele1 3X 10MP Dual Pixel Camera + Tele2 10x 10MP Dual pixel camera | 40MP front faciing camera.', '69999.00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1');
INSERT INTO `products` (`id`, `image`, `name`, `description`, `price`, `created`, `modified`, `status`) VALUES (4, '5.jpg', 'Vivo X50 Pro', 'The Vivo X50 Pro smartphone comes with 48MP+13MP+8MP+8MP rear camera with Gimbal Technology, 32MP front camera, Qualcomm Snapdragon 765G octa core processor, 8GB RAM, 256GB internal memory, 16.66 cm (6.56) FHD+ S-Amoled Curved Ultra O Display, a massive 4315mAh battery along with 33W fast charging and much more.', '49990.00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1');
INSERT INTO `products` (`id`, `image`, `name`, `description`, `price`, `created`, `modified`, `status`) VALUES (5, '8.jpg', 'Samsung Galaxy A71', 'Samsung galaxy a71 - ready action. Built for the era of life. Indulge in an immersive viewing experience with Quad Camera Setup - 64MP (F1.8) Main Camera +12MP (F2.2) Ultra Wide Camera +5MP(F2.2) Depth Camera +5MP(F2.4) Macro Camera and 32MP (F2.0) front facing Punch Hole Camera', '27999.00', '2021-03-01 09:54:21', '2021-03-01 09:54:21', '1');
INSERT INTO `products` (`id`, `image`, `name`, `description`, `price`, `created`, `modified`, `status`) VALUES (6, '6.jpg', 'Realme X2 Pro', 'Realme X2 Pro is a stylish and performance-oriented smartphone on which you can watch movies, listen to songs, play games, and do many more things. The phone features a 6.5 inches Full-HD+ Super AMOLED display, a 90Hz refresh rate, and dual surround speakers that give you a delightful viewing experience. Also, it comes with the latest in-display fingerprint from Goodix so that the user can unlock the device phone quickly (up to 0.23 s).', '29999.00', '2021-03-01 09:58:08', '2021-03-01 09:58:08', '1');
INSERT INTO `products` (`id`, `image`, `name`, `description`, `price`, `created`, `modified`, `status`) VALUES (17, '7.jpg', 'Poco X3', 'Display Features Display Size 16.94 cm (6.67 inch) Resolution 2400 x 1080 Pixels Resolution Type Full HD+ GPU Adreno 618 Display Type Full HD+ Display Other Display Features Corning Gorilla Glass 5 Screen Protection, 120 Hz Refresh Rate, 240 Hz Touch Sampling Rate, HDR 10 Os & Processor Features Operating System Android 10 Processor Type Qualcomm Snapdragon 732G Processor Core Octa Core Primary Clock Speed 2.3 GHz', '19800.00', '2021-03-01 10:04:28', '2021-03-01 10:04:28', '1');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `gender` enum('Male','Female') COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=Active | 0=Inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `gender`, `phone`, `created`, `modified`, `status`) VALUES (1, 'Akash', 'Phad', 'phad.akash2000@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'Male', '9545627203', '2021-03-05 13:59:45', '2021-03-05 13:59:45', 1);
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `gender`, `phone`, `created`, `modified`, `status`) VALUES (2, 'test', 'test', 'test@gmail.com', '098f6bcd4621d373cade4e832627b4f6', 'Male', '7020958353', '2021-03-08 15:50:07', '2021-03-08 15:50:07', 1);


